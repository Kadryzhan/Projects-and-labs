public class LSearch {


	private class Node {
		private Entry value;
		private Node nextNode;

		public Node(Entry v) {
			value = v;
			nextNode = null;
		}

		public Entry getValue() {
			return value;
		}

		public Node getNextNode() {
			return nextNode;
		}

		// Sets the NextNode to the given Node
		public void setNextNode(Node n) {
			nextNode = n;
		}
	}

	// Holds a reference to the head of the list
	private Node headNode;

	public LSearch() {
		headNode = null;
	}

	public void addAtHead(Entry e) {
		Node newNode = new Node(e); 
		newNode.setNextNode(headNode); 
		headNode = newNode; 
	}
	
	/*
	 * Part 3: complete
	 */	
	/**
	 * Uses linear search to look up a given name in the catalogue and returns the
	 * number if the name is in the catalogue. Otherwise it returns -1.
	 * 
	 * Where N is the number of entries in the catalogue the (worst case) complexity is:
	 *
	 * Big-O: O(n)
	 * 
	 * Because: in the worst situation, we examine every node from head to end once.
	 *  
	 * @param name is the person name to look for in the catalogue
	 * @return the number of that person, otherwise -1 to indicate an error
	 */
	public int linearSearch(String name){
		if (name == null || headNode == null) {
	        return -1;
	    }
		
		Node current = headNode;
		
		while (current != null) {
	        Entry e = current.getValue();	       
	       
	        if (e != null && e.getName().equals(name)) {     // check if this node is entry matches the searched name
	            return e.getNumber();                        //return the number
	        }
	        
	        current = current.getNextNode();                 // move to the next node
	    }
		return -1;                                           //if not found
	}
}
