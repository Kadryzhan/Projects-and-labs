public class ASearch {


	private Entry[] catalogue;
	private int current;
	
	/*
	 * Assume 10 entries
	 */
	public ASearch(){
		catalogue = new Entry[10];
		current = 0;
	}
	
	/*
	 * Ignores adding if full (should really be handled by exception...)
	 */
	public void addEntry(Entry e){
		if(current < 10){
			catalogue[current++] = e;
		}
	}
	
	/*
	 * Part 2: complete implementation
	 */
	/**
	 * Uses linear search to look up a given name in the catalogue and returns the
	 * number if the name is in the catalogue. Otherwise it returns -1.
	 * 
	 * Where N is the number of entries in the catalogue the (worst case) complexity is:
	 *
	 * Big-O: O(n)
	 * 
	 * Because: in the worst situation, we might look for every entry in the catalog using the sought name.
	 *  
	 * @param name is the person name to look for in the catalogue
	 * @return the number of that person, otherwise -1 to indicate an error
	 */
	public int linearSearch(String name){
		if (name == null || current == 0) {     
	        return -1;
	    }
		   
		 for (int i = 0; i < current; i++) {
		        Entry e = catalogue[i];

		        // if the name matches, return that number
		        if (e != null && e.getName().equals(name)) {
		            return e.getNumber();
		        }
		    }						
		
		return -1; // if not found
	}

	/*
	 * Part 4: complete implementation
	 */
	/**
	 * Uses binary search to look up a given name in the catalogue and returns the
	 * number if the name is in the catalogue. Otherwise it returns -1.
	 * 
	 * Where N is the number of entries in the catalogue the (worst case) complexity is:
	 *
	 * Big-O: O(log n)
	 * 
	 * Because: The search space is divided by 2 each time.
	 *  
	 * @param first the array index of the start of search space
	 * @param last the array index of the end of the search space
	 * @param name the person name being searched for
	 * @return the persons phone number if their name is found or -1 otherwise
	 */
	private int binarySearch(int first,int last,String name){    // binary search divides the list by 2 each time
		 if (first > last) {
		        return -1;      //if the range is invalid, the name is not found
		    }
		
		 
		 int mid = (first + last) / 2;  // find the middle
				
		 int cmp = catalogue[mid].getName().compareTo(name); // comparing middle with target name 
		
		
		 if (cmp == 0) {		        
		        return catalogue[mid].getNumber();          // names are equal > found return the number
		 } else if (cmp < 0) {		        
		       return binarySearch(mid + 1, last, name);    // mid name is smaller > search right half
		    
		 }  else {		        
		       return binarySearch(first, mid - 1, name);   // mid name is bigger > search left half
		    }
	}

	// helper method exposed to the programmer
	public int binarySearch(String name){
		return binarySearch(0,current-1,name);
	}
	
	
}
