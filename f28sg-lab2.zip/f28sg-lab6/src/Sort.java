
public class Sort {

	/*
	 * Part 4: complete method
	 */
	/**
	 * Sorts an array using a priority queue.
	 * 
	 * The effect of calling this method is that the input 'arr' array is
	 * updated in-place, rather than creating a new array holding the sorted value.
	 * 
	 * Where N is the number of elements in the array the complexity is:
	 *
	 * O(N log N)
	 * 
	 * Because: each insert and take out We perform N of them, and Min takes logN time.
	 * 
	 * @param arr the array to be sorted in-place
	 */
	public static void sort(int[] arr){	
		 // if the array is empty or has one element, nothing to do
        if (arr == null || arr.length <= 1) {
            return;
        }

        // create a priority queue with enough capacity
        PriorityQueue pq = new PriorityQueue(arr.length);

        // insert all elements from array into the queue
        for (int i = 0; i < arr.length; i++) {
            pq.insert(arr[i]);
        }

        // remove elements one by one in ascending order
        for (int i = 0; i < arr.length; i++) {
            arr[i] = pq.removeMin();
        }
	}
	
	public static void main(String[] args){
		int[] arr = {53,3,5,2,4,67};
		Sort.sort(arr);
		// should be printed in order
		System.out.println(arr[0]);
		System.out.println(arr[1]);	
		System.out.println(arr[2]);
		System.out.println(arr[3]);	
		System.out.println(arr[4]);	
		System.out.println(arr[5]);	
	}
	
}
