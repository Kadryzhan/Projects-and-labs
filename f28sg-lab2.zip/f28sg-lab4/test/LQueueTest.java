import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Test;

public class LQueueTest {

	LQueue q;
	@Before
	public void setup()
	{
		q = new LQueue();
	}
	
	/*
	 * 2: complete the following test methods as specified. 
	 */
	
	@Test
	public void testIsEmpty() {
		// test that q.isEmpty returns true
		assertTrue(q.isEmpty());
	}
	
	@Test
	public void testIsEmptyFalse() {
		// add an element to the queue "q"
		
		// then test that q is not an empty queue.
		 q.enqueue("A");
		 assertFalse(q.isEmpty());
	}

	@Test
	public void testSizeEmpty() {
		// test the size of an empty queue is 0
		 assertEquals(0, q.size());
	}
	
	@Test
	public void testSizeNonEmpty() {
		// add an element(s) to the queue

		// then test the size of the queue
		q.enqueue("X");
	    q.enqueue("Y");
	    assertEquals(2, q.size());
	    q.dequeue();
	    assertEquals(1, q.size());
	}

	@Test
	public void testEnqueue() {
		// enqueue an element(s) to the queue
		
		// then test that the correct element is at the front
		 q.enqueue("a");
		 q.enqueue("b");
		 assertEquals("a", q.front());
	}
	
	@Test
	public void testDequeue() {
		// enqueue multiple elements to the queue

		// then check that they are returned in the
		// correct order with dequeue.
		 q.enqueue("A");
		 q.enqueue("B");
		 q.enqueue("C");

		    assertEquals("A", q.dequeue());
		    assertEquals("B", q.dequeue());
		    assertEquals("C", q.dequeue());
	}
	
	@Test(expected = QueueException.class)  
	public void testEmptyDequeue() {  
		// try to dequeue an empty queue
		q.dequeue();
	}
	
	@Test(expected = QueueException.class)  
	public void testEmptyFront() {
		// try to get the front value of an empty queue
		q.front();
	}
}
