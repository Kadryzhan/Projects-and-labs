/*
 * Queue implementation with a linked list.
 */
public class LQueue {
	
	private class Node{
		Object element;
		Node next;
		
		public Node(Object e, Node n){
			element = e;
			next = n;
		}
		
		public Node(Object e){
			element = e;
			next = null;
		}
	}
	
	private Node head;
	private Node tail;
	private int size;
	
	public LQueue(){
		head = null;
		tail = null;	
		size = 0;
	}
	
	/*
	 * Part 3: complete the following methods
	 */
	
	// Part 3: complete	
	/**
	 * Returns true if the queue is empty, false otherwise.
	 * 
	 * Where N is the number of elements in the queue the complexity is:
	 *
	 * Big-O: O(1)
	 * 
	 * Because:  it only checks one variable size
	 */
	public boolean isEmpty(){
		return size == 0;
	}
	
	// Part 3: complete
	/**
	 * Returns how many elements are in the queue.
	 * 
	 * Where N is the number of elements in the queue the complexity is:
	 *
	 * Big-O: O(1)
	 * 
	 * Because: it just returns the size variable
	 */
	public int size(){
		return size; 
	}
	
	// Part 3: complete
	/**
	 * Adds a new element to the end of the queue.
	 * 
	 * Where N is the number of elements in the queue the complexity is:
	 *
	 * Big-O: O(1)
	 * 
	 * Because: we directly connect the new node to the tail
	 */
	public void enqueue(Object o) {
		 Node newNode = new Node(o);
	        if (isEmpty()) {
	            head = newNode;
	            tail = newNode;
	        } else {
	            tail.next = newNode;
	            tail = newNode;
	        }
	        size++;
	}
	
	// Part 3: complete	
	/**
	 * Removes the element at the front of the queue.
	 * 
	 * Where N is the number of elements in the queue the complexity is:
	 *
	 * Big-O: O(1)
	 * 
	 * Because: we just move the head pointer to the next node
	 */
	public Object dequeue() throws QueueException{
		 if (isEmpty()) {
	            throw new QueueException("Queue is empty");
	        }
	        Object removed = head.element;
	        head = head.next;
	        size--;
	        if (head == null) {
	            tail = null; // if queue becomes empty
	        }
	        
		return  removed;
	}
	
	// Part 3: complete
	/**
	 * Returns the element at the front of the queue without removing it.
	 * 
	 * Where N is the number of elements in the queue the complexity is:
	 *
	 * Big-O: O(1)
	 * 
	 * Because: we only access the head element
	 */
	public Object front() throws QueueException{
		if (isEmpty()) {
            throw new QueueException("Queue is empty");
        }
		return head.element;
	}
	
}
