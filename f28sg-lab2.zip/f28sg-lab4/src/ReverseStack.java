public class ReverseStack {


	/*
	 * 1: complete implementation
	 */
	/** Reverses the order of elements in the given stack
	 * 
	 * Where N is the number of elements in the stack the complexity is:
	 *
	 * Big-O: O(N)
	 * 
	 * Because: every element in the queue and stack is pushed and popped once.
	 * 
	 * @param st the stack to be reversed
	 */
	public static <T> void reverseStack(Stack<T> st){
		Queue<T> q = new Queue<T>(st.size()+1);
		
		//as the stack is LIFO and the queue is FIFO, this will flip the order.
		while (!st.isEmpty()) {
	            T item = st.pop();   // remove top element from stack
	            q.enqueue(item);     // put the element into the queue
	        }
		
		 while (!q.isEmpty()) {
	            st.push(q.dequeue());     // move all elements back from queue to stack
	            }		
	      }		
}
