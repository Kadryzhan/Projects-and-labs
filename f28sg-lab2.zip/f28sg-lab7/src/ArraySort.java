import java.util.ArrayList;
import java.util.Iterator;

public class ArraySort {

	/** Insertion sort of an array
	 * @param arr the array to be sorted in-place
	 */
	public static void insertionSort(int[] arr) {
		for (int i = 1; i < arr.length; i++) {
			int cur = arr[i];
			int j = i - 1;
			while (j >= 0 && arr[j] > cur) {
				arr[j + 1] = arr[j--];
				arr[j + 1] = cur;
			}
		}
	}

	/** Insertion sort of an array
	 * 
	 * This is Question 4
	 * 
	 *Where N is the number of elements in the array 'arr' the complexity is:
	 *
	 * O(N^2)
	 * 
	 * Because: two nested loops are present.Total operations ≈ N × N because the inner loop runs up to N times and the outside loop runs N times
	 * 
	 * @param arr the array to be sorted in-place
	 */
	public static void bubbleSort(int[] arr) {               
		boolean swaps = true;

	    while (swaps) {
	        swaps = false;

	        for (int i = 0; i < arr.length - 1; i++) {
	            if (arr[i] > arr[i + 1]) {
	                int temp = arr[i];
	                arr[i] = arr[i + 1];
	                arr[i + 1] = temp;

	                swaps = true;
	            }
	        }
	    }
	}

	/** Quick sort of an array. This method creates a new array with
	 * its values sorted, based on the values in the unsorted input array S.
	 * 
	 * This is Question 6
	 * 
	 * Where N is the number of elements in the array 'S' the complexity is:
	 *
	 * O(N log N)    Average case
     * O(N^2)        Worst case
	 * 
	 * Because: Around a pivot, QuickSort splits the list into two sublists.
     * LogN recursion levels → O(N log N) if the pivot splits effectively.
     * N recursion levels → O(N^2) if the pivot is consistently poor (smallest/largest).
	 * 
	 * @param S the unsorted input array
	 * @return the sorted output array
	 */
	public static ArrayList<Integer> quickSort(ArrayList<Integer> S) {		
        if (S.size() <= 1)                                             // Base case: 0 or 1 element → already sorted
            return S;       
  
        int pivot = S.get(0);                                          // Choose pivot (first element)

        ArrayList<Integer> L = new ArrayList<>(); // < 
        ArrayList<Integer> E = new ArrayList<>(); // = 
        ArrayList<Integer> G = new ArrayList<>(); // > 

        for (int x : S) {                                              // Partition the list
            if (x < pivot)
                L.add(x);
            else if (x > pivot)
                G.add(x);
            else
                E.add(x);
        }

        ArrayList<Integer> sorted = new ArrayList<>();                 // Recursively sort left and right lists

        sorted.addAll(quickSort(L));
        sorted.addAll(E);
        sorted.addAll(quickSort(G));

        return sorted;  
	  }
	
	/** predicate to check if array is sorted
	 * @param arr the array to be checked
	 * @return true if the array is sorted, false otherwise
	 */
	public static boolean isSorted(int[] arr) {
		for (int i = 0; i < arr.length - 1; i++)
			if (arr[i] > arr[i + 1])
				return false;
		return true;
	}

	
	/** predicate to check if arrayList is sorted.
	 *  Useful for checking ArrayList<Integer> lists returned
	 *  from Quick Sort.
	 * 
	 * @param arr the array to be checked
	 * @return true is the aray is sorted, flalse otherwise
	 */
	public static boolean isSorted(ArrayList<Integer> arr) {
		Iterator i = arr.iterator();
		int val;
		if (i.hasNext())
			val = (int) i.next();
		else
			return true;
		while (i.hasNext()) {
			int nv = (int) i.next();
			if (val > nv)
				return false;
			val = nv;
		}
		return true;
	}

	
	/** Helper printing methods for testing
	 * @param arr the array to print
	 */
	private static void printIntArray(int[] arr) {
		System.out.print("[ ");
		for (Integer i : arr) {
			System.out.print(i + " ");
		}
		System.out.println(" ]");
	}

	private static void printIntArrayList(ArrayList<Integer> arr) {
		System.out.print("[ ");
		for (Integer i : arr) {
			System.out.print(i + " ");
		}
		System.out.println(" ]");
	}

	public static void main(String[] args) {
		// testing part1
		int[] arr1 = { 5, 4, 3, 2, 1 };
		bubbleSort(arr1);
		printIntArray(arr1);

		// testing part2
		ArrayList<Integer> arr2 = new ArrayList<Integer>();
		arr2.add(3);
		arr2.add(1);
		arr2.add(6);
		arr2.add(5);
		ArrayList<Integer> arr2_sorted = quickSort(arr2);
		printIntArrayList(arr2_sorted);
		// {5,4,3,5,1};

	}

}
