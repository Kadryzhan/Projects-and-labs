import java.awt.Frame;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Rectangle;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.awt.geom.Rectangle2D;

public class RecursiveSquares extends Frame {

	public RecursiveSquares() {
		setSize(300, 300);
		addWindowListener(new WindowAdapter() {
			public void windowClosing(WindowEvent windowEvent) {
				System.exit(0);
			}
		});
	}

	private void drawSquare(Graphics2D g, int xPosition, int yPosition, int length, int n) {
		/* Check to see if the base case has been reached */
		if (n == 0) return; //base case: stop recursion
		
		/* Otherwise, the recursive case
		 * 
		 * Step 1: draw the square with:
		 * 
		 *      g.draw(new Rectangle2D.Double(xPosition, yPosition, length, length));
		 *      
		 * Step 2: make recursive calls to draw 4 smaller squares next time.
		 * */
	
	 //Step 1: draw the square
		g.draw(new Rectangle2D.Double(xPosition, yPosition, length, length));
	
	//calculate new smaller length
		int newLength = length / 2;
	
	//Step 2: recursive calls for 4 corners
		if(n==0) {
			return;									
		}	
		
		g.draw(new Rectangle2D.Double(xPosition-length/4, yPosition-length/4, length/2, length/2));                  // Top left
		g.draw(new Rectangle2D.Double(xPosition+length-length/4, yPosition-length/4, length/2, length/2));          //Top right
		g.draw(new Rectangle2D.Double(xPosition-length/4, yPosition+length-length/4, length/2, length/2));         //Bottom left
		g.draw(new Rectangle2D.Double(xPosition+length-length/4, yPosition+length-length/4, length/2, length/2)); //Bottom right
	
	}
	
	@Override
	public void paint(Graphics g) {
		Graphics2D g2 = (Graphics2D) g;
		// recursive pattern of order n
		int n = 2;
		drawSquare(g2, 100, 100, 100, n);
	}

	public static void main(String[] args) {
		RecursiveSquares squaresGUI = new RecursiveSquares();
		squaresGUI.setVisible(true);
	}
}
