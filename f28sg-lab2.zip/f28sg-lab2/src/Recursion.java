public class Recursion {

	// Part 1: complete
	public static int sum(int n){
		 if (n == 0) return 0;
		 return n + sum(n-1);  //recursive case: n + sum of previous numbers
	}

	// Part 1 complete
	public static int multiply(int m, int n){
		 if (n == 0) return 0;
		 if (n > 0) return m + multiply(m, n-1);  //recursive case: add m, n times
		 return -multiply(m, -n);
	}
	
	// Part 1: complete
	public static int Fibonacci(int n){
		if (n == 0) return 0;
		if (n == 1) return 1;
		return Fibonacci(n-1) + Fibonacci(n-2);
	}


}