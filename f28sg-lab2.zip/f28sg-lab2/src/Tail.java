

public class Tail {

	public static int factorial(int n) {
		return tailFactorial(n, 1); //start with result = 1
	}
	
	private static int tailFactorial(int n,int res){
		if (n == 0)
			return res;
		else 
			return tailFactorial(n-1,n*res);
	}
	
	public static int sum(int n) {
		return tailSum(n, 0); //start with sum = 0
	}
	
	// optional part
	private static int tailSum(int n,int sum){
		if (n == 0) return sum;
		return tailSum(n-1, sum+n);
	}
		
	
	public static int multiply(int m, int n) {
		return tailMultiply(m, n, 0);
	}
	
	// optional part
	private static int tailMultiply(int m,int n,int sum){
		if (n == 0) return sum;
		if (n > 0) return tailMultiply(m, n-1, sum+m); //recursive case for positive n
		return -tailMultiply(m, -n, sum);  //handle negative n
	}

}
