/* This coursework specification, and the example code provided during the
 * course, is Copyright 2026 Heriot-Watt University.
 * Distributing this coursework specification or your solution to it outside
 * the university is academic misconduct and a violation of copyright law. */

#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

/* The RGB values of a pixel. */
struct Pixel {
    int red;
    int green;
    int blue;
};

/* An image loaded from a file. */
struct Image {
    /* Question 2 */
    int width;
    int height;
    struct Pixel *pixels;
};

/* Free a struct Image */
void free_image(struct Image *img)
{
    /* Question 3a */
    if (img != NULL) {
        if (img->pixels != NULL) {
            free(img->pixels);
        }
        free(img);
    }
}

/* Opens and reads an image file, returning a pointer to a new struct Image.
 * On error, prints an error message and returns NULL. */
struct Image *load_image(const char *filename)
{
    /* Open the file for reading */
    FILE *f = fopen(filename, "r");
    if (f == NULL) {
        fprintf(stderr, "File %s could not be opened.\n", filename);
        return NULL;
    }

    /* Allocate the Image object, and read the image from the file */
    /* Question 3b */
    char header[16]; // Buffer to store the "HQDEC" string
    struct Image *img = malloc(sizeof(struct Image));
    if (img == NULL) {
        fclose(f);
        return NULL;
    }

    /* Read the HQDEC header, width, height, and skip the channels count (%*d) */
    if (fscanf(f, "%15s %d %d %*d", header, &img->width, &img->height) != 3) {
        fprintf(stderr, "File %s could not be read (invalid header).\n", filename);
        free(img);
        fclose(f);
        return NULL;
    }

    /* Allocate memory for pixels */
    img->pixels = malloc(img->width * img->height * sizeof(struct Pixel));
    if (img->pixels == NULL) {
        free(img);
        fclose(f);
        return NULL;
    }

    /* Read the RGB pixel data */
    for (int i = 0; i < img->width * img->height; i++) {
        fscanf(f, "%d %d %d", &img->pixels[i].red, 
                             &img->pixels[i].green, 
                             &img->pixels[i].blue);
    }
    /* Close the file */
    fclose(f);
    return img;
}

/* Write img to file filename. Return true on success, false on error. */
bool save_image(const struct Image *img, const char *filename)
{
    /* Question 3c */
    if (img == NULL) 
    return false;
    FILE *f = fopen(filename, "w");
    if (f == NULL) return false;

    /* Write mandatory header: HQDEC, width, height, and 3 channels */
    fprintf(f, "HQDEC %d %d 3\n", img->width, img->height);

    for (int i = 0; i < img->width * img->height; i++) {
        fprintf(f, "%d %d %d\n", img->pixels[i].red, 
                                 img->pixels[i].green, 
                                 img->pixels[i].blue);
      }
    fclose(f);
    return true;
}

/* Allocate a new struct Image and copy an existing struct Image's contents
 * into it. On error, returns NULL. */
struct Image *copy_image(const struct Image *source)
{
    /* Question 3d */
    if (source == NULL) return NULL;
    struct Image *copy = malloc(sizeof(struct Image));
    if (copy == NULL) return NULL;

    copy->width = source->width;
    copy->height = source->height;
    copy->pixels = malloc(copy->width * copy->height * sizeof(struct Pixel));
    if (copy->pixels == NULL) {
        free(copy);
        return NULL;
    }

    for (int i = 0; i < copy->width * copy->height; i++) {
        copy->pixels[i] = source->pixels[i];
    }
    return copy;
}

/* Perform your first task.
 * (TODO: Write a better comment here, and rename the function.
 * You may need to add or change arguments depending on the task.)
 * Returns a new struct Image containing the result, or NULL on error. 
 * Creates a copy of the image and increases each color channel by 30.
 * Ensures values are clamped at a maximum of 255 to prevent overflow*/
struct Image *apply_BRIGHT(const struct Image *source)
{
    /* Question 4 */
    if (source == NULL) return NULL;
    
    // Create a copy so the original image remains unchanged
    struct Image *dst = copy_image(source);
    if (dst == NULL) return NULL;

    for (int i = 0; i < dst->width * dst->height; i++) {
        // Increment each color channel by the brightness constant
        int r = dst->pixels[i].red + 30;
        int g = dst->pixels[i].green + 30;
        int b = dst->pixels[i].blue + 30;
        
        // Clamp values to the 0-255 range
        dst->pixels[i].red   = (r > 255) ? 255 : r;
        dst->pixels[i].green = (g > 255) ? 255 : g;
        dst->pixels[i].blue  = (b > 255) ? 255 : b;
    }
    return dst;
}

/* Perform your second task.
 * (TODO: Write a better comment here, and rename the function.
 * You may need to add or change arguments depending on the task.)
 * Returns true on success, or false on error. 
 * Finds the minimum and maximum brightness values in the image 
 * and scales them to the full 0-255 range*/
bool apply_NORM(const struct Image *source)
{
    /* Question 5 */
    if (source == NULL || source->pixels == NULL) return false;
    
    int min = 255, max = 0;

    // Step 1: Find global MIN and MAX values across all pixels
    for (int i = 0; i < source->width * source->height; i++) {
        if (source->pixels[i].red < min) min = source->pixels[i].red;
        if (source->pixels[i].red > max) max = source->pixels[i].red;
        
        if (source->pixels[i].green < min) min = source->pixels[i].green;
        if (source->pixels[i].green > max) max = source->pixels[i].green;
        
        if (source->pixels[i].blue < min) min = source->pixels[i].blue;
        if (source->pixels[i].blue > max) max = source->pixels[i].blue;
    }

    // If the image is a solid color, no normalization is needed
    if (max == min) return true;

    // Step 2: Apply the contrast stretching formula to each pixel
    for (int i = 0; i < source->width * source->height; i++) {
        // Formula: (value - min) * 255 / (max - min)
        source->pixels[i].red   = (source->pixels[i].red - min) * 255 / (max - min);
        source->pixels[i].green = (source->pixels[i].green - min) * 255 / (max - min);
        source->pixels[i].blue  = (source->pixels[i].blue - min) * 255 / (max - min);
    }
    return true;
}

int main(int argc, char *argv[])
{
    /* Check command-line arguments */
    /* TODO: You may need to make changes here depending on your tasks. */
    if (argc != 3) {
        fprintf(stderr, "Usage: process INPUTFILE OUTPUTFILE\n");
        return 1;
    }

    /* Load the input image */
    struct Image *in_img = load_image(argv[1]);
    if (in_img == NULL) {
        return 1;
    }

    /* Apply the first process to the input image */
    /* TODO: Change the function name and arguments to match your task. */
    struct Image *out_img = apply_BRIGHT(in_img);
    if (out_img == NULL) {
        fprintf(stderr, "First process failed.\n");
        free_image(in_img);
        return 1;
    }

    /* Apply the second process to the output of the first process */
    /* TODO: Change the function name and arguments to match your task. */
    if (!apply_NORM(out_img)) {
        fprintf(stderr, "Second process failed.\n");
        free_image(in_img);
        free_image(out_img);
        return 1;
    }

    /* Save the output image */
    if (!save_image(out_img, argv[2])) {
        fprintf(stderr, "Saving image to %s failed.\n", argv[2]);
        free_image(in_img);
        free_image(out_img);
        return 1;
    }

    free_image(in_img);
    free_image(out_img);
    return 0;
}
