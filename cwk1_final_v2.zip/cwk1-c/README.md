# F28HS Coursework 1

Description:
A program to process HQDEC images (Brightness and Normalization).

How to Compile:
Run this command in the terminal:
make

How to Run:
./process input_file.hqdec output_file.hqdec

Example:
./process ../cwk1-images/HQDEC/bars.hqdec output.hqdec