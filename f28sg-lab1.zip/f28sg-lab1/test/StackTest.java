import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Test;

/**
 * Test class for Stack operations.
 * This class tests push, pop, size, top, isEmpty, and exception handling.
 */
public class StackTest {

    Stack st;

    @Before
    public void setup() {
        
        st = new Stack(2);
    }

    /*
     * Part 1 
     */

    @Test
    public void testSizeEmpty() {
        // Test the size of an empty stack: it should be 0 since no elements have been pushed
        assertEquals(0, st.size());
    }

    @Test
    public void testSizeNonEmpty() {
        st.push("A");
        st.push("B"); 
        // Test the size of a non-empty stack: it should be 2 after two pushes
        assertEquals(2, st.size());
    }

    @Test
    public void testPopTwo() {
        st.push("A");
        st.push("B"); 
       
        assertEquals("B", st.pop());
        
        assertEquals("A", st.pop());
    }

    @Test
    public void testTopTwo() {
        st.push("A"); 
       
        assertEquals("A", st.top());
        st.push("B"); 
        
        assertEquals("B", st.top());
    }

    @Test
    public void testIsEmptyTrue() {
        // Test the boolean result from the isEmpty() method - empty stack should return true
        assertTrue(st.isEmpty());
    }

    @Test
    public void testIsEmptyFalse() {
        
        st.push("A");
       
        assertFalse(st.isEmpty());
    }

    @Test(expected = StackException.class)
    public void testEmptyPop() {
        // Try popping from an empty stack: this should throw StackException as per stack rules
        st.pop();
    }

    @Test(expected = StackException.class)
    public void testFullPush() {
       
        st.push("A"); 
        st.push("B");
        st.push("C"); 
    }
}                                                                           