/**
 * A simple calculator that evaluates expressions written
 * in Polish (prefix) notation using a stack.
 * Supports +, -, *, and / operations on integers.
 */
public class Calculator {

    
    public static class CalcError extends RuntimeException {
        public CalcError(String message) {
            super(message);
        }
    }

    /**
     * Main evaluation method.
     * @param expr array of tokens in prefix notation
     * @return result as integer
     * @throws CalcError if expression is malformed
     */
    public static int calculate(String[] expr) {
        // we use a stack that stores integers (capacity = length of expr)
        Stack stack = new Stack(expr.length);

        try {
            
            for (int i = expr.length - 1; i >= 0; i--) {
                String token = expr[i];
                if (isNumber(token)) {
                    stack.push(convert(token));
                } else {
                    
                    if (stack.size() < 2) {
                        throw new CalcError("Too few operands for operator: " + token);
                    }
                    int a = (int) stack.pop(); 
                    int b = (int) stack.pop(); 
                    int res = applyOp(a, token, b);
                    stack.push(res);
                }
            }

            // after evaluation exactly one value should remain
            if (stack.size() != 1) {
                throw new CalcError("Invalid prefix expression");
            }
            return (int) stack.pop();

        } catch (StackException e) {
            throw new CalcError("Stack failure: " + e.getMessage());
        }
    }

    /** Convert string to integer */
    public static int convert(String s) {
        return Integer.parseInt(s);
    }

    /** Check if token is a number */
    public static boolean isNumber(String s) {
        try {
            Integer.parseInt(s);
            return true;
        } catch (NumberFormatException ex) {
            return false;
        }
    }

    /** Apply operator to two integer operands */
    public static int applyOp(int left, String op, int right) {
        switch (op) {
            case "+": return left + right;
            case "-": return left - right;
            case "*": return left * right;
            case "/":
                if (right == 0) throw new CalcError("Division by zero");
                return left / right;
            default: throw new CalcError("Unknown operator: " + op);
        }
    }
}
