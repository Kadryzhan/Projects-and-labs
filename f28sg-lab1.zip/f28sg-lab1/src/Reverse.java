import static org.junit.Assert.*;
import org.junit.Test;
import java.util.Stack;

public class Reverse {

    // Part 2
    //
    // When the array 'arr' has length N. The complexity is::
    //
    // O(N)
    //
    // Due to the fact that every piece is added to the stack once (O(N))
    // and once (O(N)) popped out of the stack.  sum O(N).
    // Because: Space complexity is O(N) since the stack also contains N elements.
    public static void reverse(String[] arr) {
        Stack<String> stack = new Stack<>();

        // Push all elements into the stack
        for (String s : arr) {
            stack.push(s);
        }

        // Pop elements back into the array (reversed order)
        for (int i = 0; i < arr.length; i++) {
            arr[i] = stack.pop();
        }
    }

    @Test
    public void testReverse() {
        String[] empty = {};
        String[] one = { "A" };
        String[] three = { "A", "B", "C" };

        String[] rev_empty = {};
        String[] rev_one = { "A" };
        String[] rev_three = { "C", "B", "A" };

        Reverse.reverse(rev_empty);
        Reverse.reverse(rev_one);
        Reverse.reverse(rev_three);

        assertArrayEquals(empty, rev_empty);
        assertArrayEquals(one, rev_one);
        assertArrayEquals(three, rev_three);
    }
}
