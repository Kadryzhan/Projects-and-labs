/* 
 *
 * F28HS CW2
 * pinCrack: button input of a sequence of numbers followed by cracking a secret PIN
 * Uses interval timers for the timeout/delay function

 * Compile:    	      make cw2
 * Run (e.g):         sudo ./cw2 -d -e -s 112
 * Run (unit-test):   sudo ./cw2 -u -s 112 -r 121

 ***********************************************************************
 * The development of this code was heavily based on the wiringPi library by Gordon Henderson.
 * This instance of the code, however, does not depend directly on the wiringPi library any more.
 *
 * wiringPi:
 *	Arduino look-a-like Wiring library for the Raspberry Pi
 *	Copyright (c) 2012-2015 Gordon Henderson
 *	Additional code for pwmSetClock by Chris Hall <chris@kchall.plus.com>
 *
 *	Thanks to code samples from Gert Jan van Loo and the
 *	BCM2835 ARM Peripherals manual, however it's missing
 *	the clock section /grr/mutter/
 ***********************************************************************
 * This file is part of wiringPi:
 *	https://projects.drogon.net/raspberry-pi/wiringpi/
 *
 *    wiringPi is free software: you can redistribute it and/or modify
 *    it under the terms of the GNU Lesser General Public License as
 *    published by the Free Software Foundation, either version 3 of the
 *    License, or (at your option) any later version.
 *
 *    wiringPi is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU Lesser General Public License for more details.
 *
 *    You should have received a copy of the GNU Lesser General Public
 *    License along with wiringPi.
 *    If not, see <http://www.gnu.org/licenses/>.
 ***********************************************************************
 */

/* --------------------------------------------------------------------------- */
/* Config settings */

// NOTE: most config settings are in cw2-config.h

/* --------------------------------------------------------------------------- */
/* Imports */

#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <stdbool.h>
#include <fcntl.h>
#include <sys/mman.h>
#include <sys/time.h>
#include <unistd.h>
#include <errno.h>
#include <string.h>
#include <signal.h>
#include <time.h>
#include <math.h>
#include <assert.h>

#include "cw2-config.h"
#include "cw2-aux.h"
#include "lcd-binary.h"
#include "lcd-fcts.h"

/* --------------------------------------------------------------------------- */
/* Constants (see cw2-config.h for default values) */

// number of possible values at each position in the sequence
static  int digits = DIGITS;
// length of the sequence
static  int seqlen = SEQL;

// SECRET sequence
static int* theSeq = NULL;

// base address of GPIO memory
volatile unsigned int gpiobase ;
volatile uint32_t *gpio ;

// I2C pointer for LCD
volatile uint32_t *i2c ;

// flag to be set in signal handler for interval times
static int timed_out = 0;

/* --------------------------------------------------------------------------- */
/* external prototypes */

/* *****************************************************************************
   HINT: use this CPP flag to select between a C and an Asm implementation 
         of the Hamming distance.
 ***************************************************************************** */

#ifdef HAMM_ASM
// prototype for the Assembler fct; only needed for an Asm implementation
int hamming(const int *x, const int *y, int seqlen);
#endif

/* --------------------------------------------------------------------------- */
// Timers and signal handlers

// time-stamps for use in signal handlers
// static uint64_t startT, stopT;

/* 
   Get a timestamp in micro-seconds 
*/
uint64_t timeInMicroseconds(void){
  struct timeval tv;
  gettimeofday (&tv, NULL);
  return (uint64_t)tv.tv_sec * (uint64_t)1000000 + (uint64_t)tv.tv_usec; // in us
}

/*
  This should be a signal handler for signals issued by the interval timer.
*/
void timer_handler (int signum)
{
  /* ***************************************************************************** */
  /* COMPLETE THIS CODE (replace existing code) */
  /* ***************************************************************************** */
  timed_out = 1;
}

/* 
   Initialise the interval timer here.
*/
void initITimer(uint64_t timeout){
  /* ***************************************************************************** */
  /* COMPLETE THIS CODE */
  /* ***************************************************************************** */
  struct sigaction sa;
  struct itimerval timer;

  // Set up signal handler for SIGALRM
  memset(&sa, 0, sizeof(sa));
  sa.sa_handler = timer_handler;
  sigaction(SIGALRM, &sa, NULL);

  // Set the timer to fire once after @timeout@ microseconds
  timer.it_value.tv_sec  = timeout / 1000000;
  timer.it_value.tv_usec = timeout % 1000000;
  // No repeat
  timer.it_interval.tv_sec  = 0;
  timer.it_interval.tv_usec = 0;

  setitimer(ITIMER_REAL, &timer, NULL);
}

/* --------------------------------------------------------------------------- */
/* Helper functions for the main app */

/* 
   Initialise the secret sequence of values (of length seqlen) 
   Uses global variables: @seqlen@ for length of sequence, @digits@ for the possible number of values
*/
void initSeq(int seqlen, int digits) {
  unsigned long value, r;

  if (theSeq==NULL) {
    theSeq = calloc(seqlen, sizeof(int));
    if (theSeq==NULL) {
      failure(true, "calloc failed");
    }
  }

  srand((unsigned int)time(NULL));
  for (int i=0; i<seqlen; i++) {
    r = rand();
    value = (r % digits) + 1;
    theSeq[i] = value;
  }
}

/* 
   Show given sequence @seq@ of length @seqlen@ on the terminal.
*/
void showSeq(const int *seq, int seqlen) {
  printf("Contents of the sequence (of length %d): ", seqlen);
  for (int i=0; i<seqlen; i++) {
    printf(" %d", seq[i]);
  }
  printf("\n");
}

/* 
   Parse an integer value @val@ as a list of digits, and put them into @seq@ 
   Needed for processing command-line with options -s or -u            
*/
void readSeq(int *seq, int seqlen, int val) {
  char valStr[32];
  int i;
  size_t strLen;

  snprintf(valStr, sizeof(valStr), "%d", val);
  strLen = strlen(valStr);
  
  for (i = 0; i < seqlen && i < (int)strLen; i++) {
    seq[i] = valStr[i] - '0';
      if (seq[i] < 1 || seq[i] > digits) {
          seq[i] = 1;
      }
  }

  // pad with 1 values if necessary
  for (; i < seqlen; i++) {
      seq[i] = 1;
  }
}

/* --------------------------------------------------------------------------- */
/* Interface fcts on top of the low-level pin I/O code                         */

/* 
   Blink @led@ @c@ times
*/
void blinkN(volatile uint32_t *gpio, int led, int c) { 
  /* ***************************************************************************** */
  /* COMPLETE THIS CODE */
  /* ***************************************************************************** */
  for (int i = 0; i < c; i++) {
    digital_write(gpio, led, 1);   // LED on
    usleep(DELAY);
    digital_write(gpio, led, 0);   // LED off
    usleep(DELAY);
  }
}

/* 
   Turning LED on/off is just a call to low-level fct digital_write()
 */
static inline
void write_LED(volatile uint32_t *gpio, int pin, int value) {
  digital_write (gpio, pin, value);
}

/* ----------------------------------------------------------------------------- */
/* Helper fcts for this app                                                      */

/*
  HINT: the libc function powl(x, n) computes @x@ to the power of @n@
        and is a useful function for Task~5, using arbitrary sequence length.
*/

/* ***************************************************************************** */
/* NOTE: CPP flag should select Assembler version of Hamming distance            */
/*       Set the flag in the Makefile using -DHAMM_ASM                           */
/* If the flag is NOT set (as below) a C version of the Hamming distance should be selected */
/* ***************************************************************************** */

#ifndef HAMM_ASM
/*
  Computer the Hamming distance between to arrays of ints.
  OPTIONAL: this is a C implementation of Hamming distance; this version is optional
  HINT: implement a C version and test it, before implementing an ARM Assembler version
  NOTE: if you use a C implementation, you may need to modify the Makefile and remove 'hamming.o' from the list of linked files.
  The final version of the code should use the Assembler version in file hamming.s
*/
int hamming(const int *x, const int *y, int seqlen) {
  /* ***************************************************************************** */
  /* COMPLETE THIS CODE (C version is OPTIONAL, but you need an implementation of hamming() */
  /* ***************************************************************************** */
  int dist = 0;
  for (int i = 0; i < seqlen; i++) {
    if (x[i] != y[i]) dist++;
  }
  return dist;
}
#endif

/*
  Show the Hamming distance (of @seq1@ and @seq2@) in @code@ on the terminal.
*/
void showHamm(int code, const int *seq1, const int *seq2) {
  /* ***************************************************************************** */
  /* COMPLETE THIS CODE */
  /* ***************************************************************************** */
  printf("Hamming distance:\n%d\n", code);
}

/* 
   OPTIONAL: implement an increment in a array of arbitrary length in @seq@
             by one, assuming the max value per element is @digits@.
  HINT: this function is useful for Task 3: arbitrary length of sequence.	     
*/
static inline
void incseq(int *seq, int seqlen,  int digits){
  /* ***************************************************************************** */
  /* OPTIONALLY COMPLETE THIS CODE */
  /* ***************************************************************************** */
  for (int i = seqlen - 1; i >= 0; i--) {
    seq[i]++;
    if (seq[i] <= digits) break;
    seq[i] = 1; // wrap and carry
  }
}

/* --------------------------------------------------------------------------- */

/* 
   @submit_PIN@: Submit a PIN for checking against a secret pin.  EXPENSIVE!
   @attSeq@ is the attempted sequence, submitted for testing against the secret pin.
   @seqlen@ is the length of the sequence.
   @submitDelay@ is the delay in processing the sequence (can be changed with -S cmdline option).
   NOTE: the secret sequence is in the global variable @theSeq@ which is not an argument
         because it should be hidden to the caller.
   The function tests @attSeq@ against the secret sequence @theSeq@, by computing the Hamming distance.
   If the Hamming distance is 0, both sequences are equal, and the sequence has been found (in @attSeq@)
   The return value is a boolean value whether the sequence has been found.
*/

int submit_PIN(const int *attSeq, int seqlen, int submitDelay) {
  int found = 0;
  
  // debugging only (needs additional arguments!):
  // showSeq(attSeq,seqlen);   showHamm(code, refSeq, attSeq);

  // submits++;         // now done at caller side
  usleep(submitDelay);  // simulating a slow submit action
  found = hamming(theSeq, attSeq, seqlen) == 0;
  return found;
}

/* +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ */

int main(int argc, char **argv){
  int found = 0, code = 0, refCode = 0;
  int buttonPressed = 0;

  // use these to count: number of comparisons in total, found after how many attempts, total number of submits
  int attempts = 0, found_at = 0, submits = 0;
  int *attemptSeq = NULL, *refSeq = NULL; 
  double startTime, stopTime;

  // variables holding Pin numbers for LEDs and button
  int pinLED = LED, pinLED2 = LED2, pinButton = BUTTON;
  int   fd ;

  // strings for temporary usage (e.g. writing to LCD display)
  char str1[32];
  char str2[32];

  // variables for command-line processing
  bool opt_e = false, opt_l = false;
  int opt_m = 0, opt_n = 0, opt_S = 0, opt_s = 0, opt_r = 0;
  bool verbose = false, help = false, debug = false, unit_test = false;
  int submitDelay = SUBMIT_DELAY;
  
  // -------------------------------------------------------
  // process command-line arguments

  { // see the CW spec for the intended meaning of these options
    int opt;
    while ((opt = getopt(argc, argv, "hvdeluS:s:r:m:n:")) != -1) {
      switch (opt) {
      case 'v':
	verbose = true;
	break;
      case 'h':
	help = true;
	break;
      case 'd':
	debug = true;
	break;
      case 'e':
	opt_e = true;
	break;
      case 'l': // LCD test only
	opt_l = true;
	break;
      case 'u':
	unit_test = true;
	break;
      case 'S':
	opt_S = atoi(optarg);
	submitDelay = opt_S;
	break;
      case 's':
	opt_s = atoi(optarg); 
	break;
      case 'r':
	opt_r = atoi(optarg); 
	break;
      case 'm':
	opt_m = atoi(optarg);
	digits = opt_m;
	break;
      case 'n':
	opt_n = atoi(optarg);
	seqlen = opt_n;
	break;
      default: /* '?' */
	fprintf(stderr, "Usage: %s [-h] [-v] [-d] [-e] [-m <maxval> ] [-n <seqlen>] [-u <seq1> <seq2>] [-s <secret seq>] [-r <reference seq>]  \n", argv[0]);
	exit(EXIT_FAILURE);
      }
    }
  }

  if (help) {
    fprintf(stderr, "pinCrack program, running on a Raspberry Pi, with connected LED, button and LCD display\n"); 
    fprintf(stderr, "Use the button for input of numbers. The LCD display will show the matches with the secret sequence.\n"); 
    fprintf(stderr, "For full specification of the program see: https://www.macs.hw.ac.uk/~hwloidl/Courses/F28HS/F28HS_CW2_2026.pdf\n"); 
    fprintf(stderr, "Usage: %s [-h] [-v] [-d] [-e] [-u <seq1> <seq2>] [-s <secret seq>] [-r <reference seq>]  \n", argv[0]);
    exit(EXIT_SUCCESS);
  }

  if (verbose) {
    printf("Settings for running the program\n");
    printf("Verbose is %s\n", (verbose ? "ON" : "OFF"));
    printf("Debug is %s\n", (debug ? "ON" : "OFF"));
    printf("Unittest is %s\n", (unit_test ? "ON" : "OFF"));
    printf("Exhaustive search is %s\n", (opt_e ? "ON" : "OFF"));
    printf("Submit delay is %d\n", submitDelay);
    if (opt_s)  printf("Secret sequence set to %d\n", opt_s);
    if (opt_r)  printf("Reference sequence set to %d\n", opt_r);
  }

  if (verbose) {
    printf("Hint: remember to compute the Hamming distance in each iteration and assign it to variable code; current (unused) value: %d\n", code);
    printf("Code style requirement: collect the values of the input sequence in the variable attemptSeq; current (unused) value: %p\n", attemptSeq);
  }  

  /* ***************************************************************************** */
  /* COMPLETE THIS CODE */
  /* Initialise the sequences that you need here, before using them  */
  /* ***************************************************************************** */

  if (opt_s) {
    if (theSeq==NULL) {
      theSeq = calloc(seqlen, sizeof(int));
      if (theSeq==NULL) failure(true, "calloc failed");
    }
    readSeq(theSeq, seqlen, opt_s);
    if (verbose) {
      fprintf(stderr, "Running program with secret sequence:\n");
      showSeq(theSeq, seqlen);
    }
  }
  
  if (opt_r) {
    if (refSeq==NULL) {
      refSeq = calloc(seqlen, sizeof(int));
      if (refSeq==NULL) failure(true, "calloc failed");
    }
    readSeq(refSeq, seqlen, opt_r);
    if (verbose) {
      fprintf(stderr, "Running program with reference sequence:\n");
      showSeq(refSeq, seqlen);
    }
  }

  // Allocate attemptSeq (coding style requirement)
  attemptSeq = calloc(seqlen, sizeof(int));
  if (attemptSeq == NULL) failure(true, "calloc failed for attemptSeq");
  
  /* --------------------------------------------------------------------------- */
  /* Configuration of the LCD display */
  int bits, rows, cols ;

  bits = 4; 
  cols = 16; 
  rows = 2; 

  printf ("Raspberry Pi configuration: red LED: %d; green LED: %d; button: %d\n", pinLED2, pinLED, pinButton) ;
  printf ("Raspberry Pi LCD driver for a %dx%d display (%d-bit wiring) \n", cols, rows, bits) ;

  /* --------------------------------------------------------------------------- */
  /* Check for root priveleges */

  if (geteuid () != 0) {
    fprintf (stderr, "setup: Must be root. (Did you forget sudo?)\n") ;
    exit(EXIT_FAILURE);
  }
  
  /* --------------------------------------------------------------------------- */
  // RPi4 base address
  gpiobase = 0xFE200000 ;

  // Open /dev/mem
  if ((fd = open ("/dev/mem", O_RDWR | O_SYNC | O_CLOEXEC) ) < 0)
    return failure (false, "setup: Unable to open /dev/mem: %s\n", strerror (errno)) ;

  // GPIO mapping
  gpio = mmap(0, BLOCK_SIZE, PROT_READ|PROT_WRITE, MAP_SHARED, fd, gpiobase) ;
  if ((int32_t)gpio == -1)
    return failure (false, "setup: mmap (GPIO) failed: %s\n", strerror (errno)) ;

  // I2C mapping for LCD
  i2c = mmap(0, I2C_LEN, PROT_READ|PROT_WRITE, MAP_SHARED, fd, I2C_BASE);
  if ((int32_t)i2c == -1)
    return failure(false, "setup: mmap (I2C) failed: %s\n", strerror(errno));

  // Set I2C slave address
  i2c[3] = 0x27;

  // Set I2C clock divider (400kHz)
  i2c[5] = 0x05DC;

  // Enable I2C
  i2c[0] = 0x8000;

  usleep(10000);
  /* ***************************************************************************** */
  /* COMPLETE THIS CODE */
  /* Set the mode for the pins here, using the low-level functions in lcd-binary.c */
  /* ***************************************************************************** */
  pin_mode(gpio, pinLED,    OUTPUT); // green LED -> output
  pin_mode(gpio, pinLED2,   OUTPUT); // red LED   -> output
  pin_mode(gpio, pinButton, INPUT);  // button    -> input

  /* ***************************************************************************** */
  /* COMPLETE THIS CODE */
  /* Initialise the LCD display */
  /* ***************************************************************************** */
  lcd_init(i2c);

  if (opt_l) {
    /* ***************************************************************************** */
    /* OPTIONAL CODE to show that the LCD display is working */
    /* ***************************************************************************** */
    lcd_string(i2c, "pinCrack ready", LCD_LINE_1);
    lcd_string(i2c, "LCD test OK",    LCD_LINE_2);
    exit(2);
  }
  
  // -----------------------------------------------------------------------------
  // App initialisation
  
  /* Initialise the secret sequence */
  if (!opt_s)  initSeq(seqlen, digits);

  /* Use the debugging option like this for extra messages */
  if (debug) {
    printf("Secret sequence is: ");
    showSeq(theSeq,seqlen);
  }

  // -----------------------------------------------------------------------------
  // Unit testing

  if (unit_test) {
    if (!opt_r) {
      fprintf(stderr, "Need to use both -s and -r for unit testing (with -u)\n");
      exit(EXIT_FAILURE);
    }
    refCode = hamming(theSeq, refSeq, seqlen);
    showSeq(theSeq,seqlen);
    showSeq(refSeq,seqlen);
    showHamm(refCode, theSeq, refSeq); 
    exit(EXIT_SUCCESS);
  }  

  // -----------------------------------------------------------------------------
  
  /* Print Greetings Message on LCD display */
  /* ***************************************************************************** */
  /* COMPLETE THIS CODE */
  /* ***************************************************************************** */
  {
    // Task 1: blink LEDs for first 5 letters of surname
    // consonant = red LED, vowel = green LED
    const char *surname = "Kuben"; // TODO: replace with your actual surname
    char display[6] = {0};

    for (int i = 0; surname[i] != '\0' && i < 5; i++) {
      char c  = surname[i];
      char cl = (c >= 'A' && c <= 'Z') ? (char)(c + 32) : c;

      display[i] = c;
      lcd_string(i2c, display, LCD_LINE_1);

      if (cl=='a' || cl=='e' || cl=='i' || cl=='o' || cl=='u') {
        blinkN(gpio, pinLED, 1);   // green = vowel
      } else {
        blinkN(gpio, pinLED2, 1);  // red = consonant
      }
      usleep(DELAY);
    }
  }

  /* OPTIONAL: wait for ENTER key before continuing */
  waitForEnter () ;

  /* +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ */
  /* Main part of the application  */

  // -------------------------------------------------------
  // PHASE 1: sequence input

  if (opt_r) {
    // -r option: skip button input, use refSeq directly
    for (int i = 0; i < seqlen; i++) attemptSeq[i] = refSeq[i];

  } else {
    // Read each digit via button presses with timeout
    for (int i=0; i<seqlen; i++) {

      /* ***************************************************************************** */
      /* COMPLETE THIS CODE (replace existing code)                                    */
      /* ***************************************************************************** */
      int presses = 0;
      timed_out   = 0;

      // Start timeout timer
      initITimer(TIMEOUT);

      printf("Enter digit %d/%d (press button; timeout ends input):\n", i+1, seqlen);

      // Count button presses until timer fires
      while (!timed_out) {
        buttonPressed = read_button(gpio, pinButton);

        if (buttonPressed) {
          write_LED(gpio, pinLED, 1);          // green LED on

          while (read_button(gpio, pinButton)) // wait for release
            usleep(50000);

          write_LED(gpio, pinLED, 0);
          presses++;

          // Reset timer after each press
          timed_out = 0;
          initITimer(TIMEOUT);
          usleep(50000);
        }
      }

      // Clamp to valid range 1..digits
      if (presses < 1)      presses = 1;
      if (presses > digits) presses = digits;

      attemptSeq[i] = presses;
      printf("Digit %d entered: %d\n", i+1, presses);

      // Red LED blinks once: acknowledge input
      blinkN(gpio, pinLED2, 1);
      usleep(DELAY);

      // Green LED echoes the entered number
      blinkN(gpio, pinLED, presses);
      usleep(DELAY);

      // Show on LCD
      snprintf(str1, sizeof(str1), "Input: %d/%d    ", i+1, seqlen);
      snprintf(str2, sizeof(str2), "Value: %d       ", presses);
      lcd_string(i2c, str1, LCD_LINE_1);
      lcd_string(i2c, str2, LCD_LINE_2);
    }

    // Red LED blinks twice: end of input
    blinkN(gpio, pinLED2, 2);

    // Copy attemptSeq into refSeq for search
    if (refSeq == NULL) {
      refSeq = calloc(seqlen, sizeof(int));
      if (refSeq == NULL) failure(true, "calloc failed for refSeq");
    }
    for (int i = 0; i < seqlen; i++) refSeq[i] = attemptSeq[i];
  }

  printf("Input sequence: ");
  showSeq(attemptSeq, seqlen);

    // -------------------------------------------------------
    // PHASE 2: Main Task: full search

    printf("--------------------- \n");
    printf(">> Version %d: %s with %d digits and %d sequence length\n", VERSION, VERSION_STR, digits, seqlen);
#ifdef HAMM_ASM
    printf(">> HAMM_ASM version: Hamming distance in ARM Assembler\n");
#else
    printf(">> Hamming in C version\n");
#endif
    printf("--------------------- \n");

    if (debug) {
      printf("Debug mode\nThe secret sequence is:");
      showSeq(theSeq,seqlen);
    }

    // Total number of possible sequences
    unsigned long bound = powl(digits, seqlen);

    // Task 3: Compute and show Hamming distance between input and secret
    code = hamming(theSeq, refSeq, seqlen);
    printf("Hamming distance between input and secret: %d\n", code);
    showHamm(code, refSeq, theSeq);

    // Show on LCD
    snprintf(str1, sizeof(str1), "Hamming: %d      ", code);
    lcd_string(i2c, str1,             LCD_LINE_1);
    lcd_string(i2c, "Searching...    ", LCD_LINE_2);

    startTime = clock();

    /* ***************************************************************************** */
    /* COMPLETE THIS CODE                                                            */
    /* Tasks 4 & 5: search for the secret sequence                                  */
    /* ***************************************************************************** */

    int *candidate = calloc(seqlen, sizeof(int));
    if (candidate == NULL) failure(true, "calloc failed for candidate");
    for (int i = 0; i < seqlen; i++) candidate[i] = 1; // start at {1,1,...,1}

    for (unsigned long idx = 0; idx < bound; idx++) {
      attempts++;

      // Only submit candidates whose Hamming distance from refSeq == code
      if (hamming(refSeq, candidate, seqlen) == code) {
        submits++;
        if (submit_PIN(candidate, seqlen, submitDelay)) {
          if (!found) {
            found    = 1;
            found_at = attempts;
            printf("Secret PIN found at attempt %d: ", attempts);
            showSeq(candidate, seqlen);

            // Build LCD string
            char lcdSeq[17] = {0};
            int pos = 0;
            for (int k = 0; k < seqlen && pos < 15; k++)
              pos += snprintf(lcdSeq + pos, sizeof(lcdSeq) - pos, "%d", candidate[k]);

            lcd_string(i2c, "PIN found!      ", LCD_LINE_1);
            lcd_string(i2c, lcdSeq,             LCD_LINE_2);

            // Green LED blinks twice: found!
            blinkN(gpio, pinLED, 2);
          }
          if (!opt_e) break; // stop unless exhaustive mode
        }
      }

      // Advance to next candidate
      incseq(candidate, seqlen, digits);
    }

    free(candidate);

    stopTime = clock();

    printf("Runtime; %f secs\n", (stopTime-startTime)/CLOCKS_PER_SEC);
    printf("Sequence %s\n", found ? "found" : "not found");
    printf("%s search finished for %d digits and %d seqlen (expect %ld):\n%d attempts (found at %d i.e. %.2f %%), %d submits\n",
	 (opt_e ? "Exhaustive" : "Non-exhaustive"), digits, seqlen, bound, attempts, found_at, (float)found_at / ((float)bound / 100.0), submits);
    printf("Secret sequence was: ");
    showSeq(theSeq,seqlen);

  /* ***************************************************************************** */
  /* COMPLETE THIS CODE                                                            */
  /* write an exit message to the LCD display                                      */
  /* ***************************************************************************** */
  snprintf(str1, sizeof(str1), "%s      ", found ? "Found!" : "Not found");
  lcd_string(i2c, "Search done!    ", LCD_LINE_1);
  lcd_string(i2c, str1,              LCD_LINE_2);

  free(theSeq);
  free(refSeq);
  free(attemptSeq);

 return 0;
}
