#include <stdio.h>
#include <stdint.h>
#include <fcntl.h>
#include <sys/mman.h>
#include <unistd.h>
#include <string.h>
#include "cw2-config.h"
#include "cw2-aux.h"
#include "lcd-fcts.h"
#include "lcd-binary.h"


void lcd_toggle_enable(volatile uint32_t *i2c, uint8_t bits) {
    //usleep(E_DELAY);
    i2c_send_byte(i2c, bits | ENABLE);
    usleep(E_PULSE);
    i2c_send_byte(i2c, bits & ~ENABLE);
    usleep(E_DELAY);
}

void lcd_byte(volatile uint32_t *i2c, uint8_t bits, uint8_t mode) {

    uint8_t bits_high = mode | (bits & 0xF0) | LCD_BACKLIGHT;
    uint8_t bits_low = mode | (bits << 4)  | LCD_BACKLIGHT;

    i2c_send_byte(i2c, bits_high);
    lcd_toggle_enable(i2c, bits_high);

    i2c_send_byte(i2c, bits_low);
    lcd_toggle_enable(i2c, bits_low);
}

 void lcd_init(volatile uint32_t *i2c) {
    // Initialize 4-bit mode
    lcd_byte(i2c, 0x33, LCD_CMD);
    lcd_byte(i2c, 0x32, LCD_CMD);

    // Set function, display, entry mode, and clear display
    lcd_byte(i2c, 0x28, LCD_CMD); // 4-bit mode, 2 lines, 5x8 dots
    lcd_byte(i2c, 0x0C, LCD_CMD); // Display on, cursor off
    lcd_byte(i2c, 0x06, LCD_CMD); // Entry mode set
    lcd_byte(i2c, 0x01, LCD_CMD); // Clear display

    usleep(E_DELAY);
}

void lcd_string(volatile uint32_t *i2c, const char *message, uint8_t line) {
    lcd_byte(i2c, line, LCD_CMD);
    for (int i = 0; i < strlen(message); i++) {
         //lcd_byte(i2c, (i < strlen(message)) ? message[i] : ' ', LCD_CHR);//lcd_byte(i2c, message[i], LCD_CHR);
         lcd_byte(i2c, message[i], LCD_CHR);
    }
}

