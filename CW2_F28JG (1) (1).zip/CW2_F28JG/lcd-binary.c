#include <stdio.h>  // debugging only
#include "gpio.h"
#include "lcd-binary.h"
#include "cw2-aux.h"
#include <sys/ioctl.h>
#include <fcntl.h>
#include <unistd.h>

/* ***************************************************************************** */
/* HINT: use the CPP variable ASM with ifdef's to select Asm (or C) versions of the code. */
/* ***************************************************************************** */

/*
  Hardware Interface function.
  Set the mode for pin number @pin@ to @mode@ (can be INPUT or OUTPUT (encoded as int)).
*/
void pin_mode(volatile uint32_t *gpio, int pin, int mode)
{
  /* ***************************************************************************** */
  /* COMPLETE THIS CODE */
  /* ***************************************************************************** */
#ifdef ASM
  __asm__ volatile (
    /* R2 = gpio base address (coding style requirement) */
    "MOV R2, %[gpio]          \n\t"

    /* Compute GPFSEL register index: R3 = pin / 10 */
    /* Use repeated subtraction (UDIV not supported in ARM mode) */
    "MOV R0, %[pin]           \n\t"
    "MOV R3, #0               \n\t"
    "MOV R1, #10              \n\t"
    "1:                       \n\t"
    "CMP R0, R1               \n\t"
    "BLT 2f                   \n\t"
    "SUB R0, R0, R1           \n\t"
    "ADD R3, R3, #1           \n\t"
    "B   1b                   \n\t"
    "2:                       \n\t"

    /* R4 = (pin % 10) * 3 */
    "MOV  R4, R0              \n\t"
    "ADD  R4, R4, R4, LSL #1  \n\t"

    /* Load GPFSELn */
    "LDR  R5, [R2, R3, LSL #2]\n\t"

    /* Clear 3 bits */
    "MOV  R6, #7              \n\t"
    "LSL  R6, R6, R4          \n\t"
    "BIC  R5, R5, R6          \n\t"

    /* Set mode bits */
    "MOV  R6, %[mode]         \n\t"
    "LSL  R6, R6, R4          \n\t"
    "ORR  R5, R5, R6          \n\t"

    /* Write back */
    "STR  R5, [R2, R3, LSL #2]\n\t"

    :
    : [gpio] "r" (gpio), [pin] "r" (pin), [mode] "r" (mode)
    : "r0", "r1", "r2", "r3", "r4", "r5", "r6", "cc", "memory"
  );
#else
  /* C fallback */
  int reg   = pin / 10;
  int shift = (pin % 10) * 3;
  uint32_t val = gpio[reg];
  val &= ~(7u << shift);
  val |=  ((uint32_t)mode << shift);
  gpio[reg] = val;
#endif
}

/*
  Hardware Interface function.
  Send a @value@ along pin number @pin@. Values should be LOW or HIGH (encoded as int).
*/
void digital_write (volatile uint32_t *gpio, int pin, int value)
{
  /* ***************************************************************************** */
  /* COMPLETE THIS CODE */
  /* ***************************************************************************** */
#ifdef ASM
  __asm__ volatile (
    "MOV  R2, %[gpio]         \n\t"
    "MOV  R0, #1              \n\t"
    "MOV  R1, %[pin]          \n\t"
    "LSL  R0, R0, R1          \n\t"
    "CMP  %[value], #0        \n\t"
    "BEQ  3f                  \n\t"
    "STR  R0, [R2, #28]       \n\t"  /* GPSET0 */
    "B    4f                  \n\t"
    "3:                       \n\t"
    "STR  R0, [R2, #40]       \n\t"  /* GPCLR0 */
    "4:                       \n\t"
    :
    : [gpio] "r" (gpio), [pin] "r" (pin), [value] "r" (value)
    : "r0", "r1", "r2", "cc", "memory"
  );
#else
  /* C fallback */
  uint32_t mask = 1u << pin;
  if (value) {
    gpio[7]  = mask;
  } else {
    gpio[10] = mask;
  }
#endif
}

/*
  Hardware Interface function.
  Read input from a button device connected to pin @button@. Result can be LOW or HIGH (encoded as int).
*/
int read_button(volatile uint32_t *gpio, int button) {
  /* ***************************************************************************** */
  /* COMPLETE THIS CODE */
  /* ***************************************************************************** */
  // fill in your code and replace the return statement below with the value read from the button
  int result = LOW;
#ifdef ASM
  __asm__ volatile (
    "MOV  R2, %[gpio]         \n\t"
    "LDR  R0, [R2, #52]       \n\t"  /* GPLEV0 */
    "MOV  R1, %[button]       \n\t"
    "LSR  R0, R0, R1          \n\t"
    "AND  R0, R0, #1          \n\t"
    "MOV  %[result], R0       \n\t"
    : [result] "=r" (result)
    : [gpio] "r" (gpio), [button] "r" (button)
    : "r0", "r1", "r2", "cc"
  );
#else
  /* C fallback */
  uint32_t level = gpio[13];
  result = (level >> button) & 1;
#endif
  return result;
}

/*
  Hardware Interface function.
  Send a @byte@ to display.
*/
void i2c_send_byte(volatile uint32_t *i2c, uint8_t byte)
{
  /* ***************************************************************************** */
  /* COMPLETE THIS CODE */
  /* ***************************************************************************** */
  int fd;
  fd = open("/dev/i2c-1", O_RDWR);
  if (fd < 0) {
    fprintf(stderr, "Cannot open /dev/i2c-1\n");
    return;
  }
  
  if (ioctl(fd, 0x0703, 0x27) < 0) {
    fprintf(stderr, "Cannot set I2C address\n");
    close(fd);
    return;
  }
  
  write(fd, &byte, 1);
  close(fd);
}
