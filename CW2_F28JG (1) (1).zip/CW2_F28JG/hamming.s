@ Task: compute the Hamming distance on 2 words
@       Given:  2 integer arrays xs and ys, where len(xs)==len(ys)
@       Return: the number of positions where the two arrays differ
@               i.e. | { i | i <- 0..len(xs), xs[i]!=ys[i] } |
	
@ Follows ARM subroutine calling conventions
	
	@ Entry point (Callable from C): 
	.global hamming
	
hamming:		  @ Input: 2 ptrs to int arrays in R0 and R1, length in R2
			  @ don't forget to push relevant registers here
	PUSH {R4, R5, R6, LR}

	MOV  R3, #0
	MOV  R4, #0
loop:
	CMP  R3, R2
	BGE  done
	LDR  R5, [R0, R3, LSL #2]
	LDR  R6, [R1, R3, LSL #2]
	CMP  R5, R6
	ADDNE R4, R4, #1
	ADD  R3, R3, #1
	B    loop
done:
	MOV  R0, R4
			  @ don't forget to pop relevant registers here
	POP  {R4, R5, R6, LR}
	BX   LR

@ Test data	
.data
.equ VAL1, 1
.equ VAL2, 2	
@ Indicate to the linker that the code in this file does not need the stack
@ to be executable. (Recent versions of GNU ld warn if this is not present.)
.section .note.GNU-stack,"",%progbits